import turtle


MySetting = {

    'Shashli' : {

    'color' : 'pink',
    'width' : 60,
    'length': 60,
    'Left' : 45,
    'NumberLeft' : 1,
    'rotations'  : 4,

    },

    'hastzeli' : {

    'color' : 'green',
    'width' : 60,
    'length': 60,
    'Left' : 60,
    'NumberLeft' : 1,
    'rotations'  : 3,

    },


    'Rectangle':{

    'color' : 'red',
    'width' : 30,
    'length': 60,
    'Left' : 90,
    'NumberLeft' : 1,
    'rotations'  : 2,

    }, 

    'Square'   : {

    'color' : 'blue',
    'width' : 40,
    'length': 40,
    'Left' : 90,
    'NumberLeft' : 1,
    'rotations'  : 2,


    },

    'Triangle' :{

    'color' : 'green',
    'width' : 70,
    'length': 70,
    'Left' : 120,
    'NumberLeft' : 1,
    'rotations'  : 2,

    },


}





import turtle
import shapes
# from setting import MySetting



turtle.done()

import turtle
turtle.speed(0)

import TurtleRandom

TurtleRandom.random_f_star()
import TurtleStar

TurtleRandom.random_f()

import TurtleHome

